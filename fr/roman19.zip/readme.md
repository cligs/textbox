French Novels published between 1860 and 1889
=============================================

## Contents
* The collection contains crime fiction, fantastic and adventure novels from the 1860s, 1870s and 1880s.
* See the "metadata.csv" file, it contains basic information about the novels.

## Formats 

* tei: Encoded following the Guidelines of the Text Encoding Initiative (File names: identifier.xml)
* txt: Simple plain text containing only the main text of the novels (File names: author_title-identifier.txt)

## License

* All texts are in the public domain and therefore licensed as CC-0. We would however appreciate it if you could mention the CLiGS group and the URL of this repository if you use these texts in your teaching or research.  

 
