Spanish Novel from 1980-1940
========================================

This corpus contains  24 texts from 8 Spanish authors and it is the first release of the whole corpus of the PhD thesis of José Calvo Tello, who is part of the young research group CLiGS, at the University of Würzburg, Germany.

## Formats

* tei: following the Text Encoding Initiative (File name: id)
* txt: simple plain text of the body (File name: Author_Title)

## Copyright

* The author's copyright of this texts have already expired. This collection is published under Creative Common Attribution 4.0 International.
